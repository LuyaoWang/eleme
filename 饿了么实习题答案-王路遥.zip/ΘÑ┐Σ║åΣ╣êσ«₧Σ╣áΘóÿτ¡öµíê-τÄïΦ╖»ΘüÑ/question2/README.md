开发方面的环境：
gulpfile.js写了一个预处理。
package.json写了依赖的包。
运行gulp可下载node_modules.

实际答案:
public:
index-demo页面，
assets--js--slider.js 实现的轮滑
    |    |--ie8supports.js引用的一个ie8依赖
    |
    | --images资源图片里面有写的js和一个ie8支持文件，css和图片。
    |
    | --slider.css 轮播的css代码
    | --style.css 轮播的demo代码

source--生成的css的scss代码
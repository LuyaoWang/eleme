'use strict';
var gulp        = require('gulp');
var browserSync = require('browser-sync');
var sass        = require('gulp-sass');
var autoprefixer = require('gulp-autoprefixer');

gulp.task('default', ['sass', 'server'], function() {
    gulp.watch('source/**/*.{sass,scss}', ['sass']);
});


gulp.task('server', function() {
    browserSync({
        files: [
            'public/**'
        ],
        server: {
            baseDir: 'public/'
        },
        notify: false,
        open: false
    });
});

gulp.task('sass', function() {
    return gulp.src('source/**/*.{sass,scss}')
        .pipe(sass({
        }))
        .pipe(autoprefixer({
            browsers: ['last 2 versions'],
            cascade: false
        }))
        .pipe(gulp.dest('public/assets/'))
        .pipe(browserSync.reload({stream: true}));
});

